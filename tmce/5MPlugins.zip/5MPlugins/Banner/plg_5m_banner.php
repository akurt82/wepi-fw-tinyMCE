<?php

	session_start();

	/* ******************************************************************** *
	 *
	 * Part of the 5M-Ware TinyMCE-Plugin-Pool
	 *
	 * Copyright©, 2016
	 * 5M-Ware
	 * info@5m-ware.de
	 * Programmed and designed by Abdülaziz Kurt
	 *
	 * ******************************************************************** */

	$lang == "";

	if ( isset($_SESSION['page.language']) ) { $lang = $_SESSION['page.language']; } else
	{
		if ( isset($_SESSION['tinymce.language']) ) { $lang = $_SESSION['tinymce.language']; } else	
		{
			if ( isset($_SESSION['tinymce.lang']) ) { $lang = $_SESSION['tinymce.lang']; } else	
			{
				if ( isset($_SESSION['lang']) ) { $lang = $_SESSION['lang']; }
			}
		}
	}
	if ( $lang == "" ) { $lang = "en"; }

	if ( $lang == "tr" ) {
		$tab0 = "Resimleri se&ccedil;";
		$tab1 = "Ayarlar";
		$tab2 = "Mevcut bir Banner kullan";
		$navi = "Navigasyon";
		$butt = "Butonlar";
		$conf = "&Ouml;zellikler";
	} elseif ( $lang == "de" ) {
		$tab0 = "Bilder ausw&auml;hlen";
		$tab1 = "Einstellungen";
		$tab2 = "Einen verf&uuml;gbaren Banner nutzen";
		$navi = "Navigation";
		$butt = "Buttons";
		$conf = "Eigenschaften";
	} else {
		$tab0 = "Select images";
		$tab1 = "Settings";
		$tab2 = "Use an available banner";
		$navi = "Navigation";
		$butt = "Buttons";
		$conf = "Properties";
	}

?>

<!doctype html>

<html>
	<head>
    <script type="text/javascript" src="../../../api/wepi_core.js"></script>
    <script>
    	var svr = new wepiServ();
    		svr.sessionID = "<?php echo session_id(); ?>";
    	// *** //
    	function tabIt(index) {
    		var i;
    		for ( i = 0; i < 3; i++ ) {
    			$("#tab"+i).css("background-color","");
    			$("#tab"+i).css("color","");
    			$("#panel"+i).fadeOut("fast");
    		}
   			$("#tab"+index).css("background-color","rgb(80,105,140)");
   			$("#tab"+index).css("color","#ffffff");
   			$("#panel"+index).fadeIn("slow");
    	}
    </script>
    <style>
    	body {
    		padding: 0;
    		margin: 0;
    		background-color:rgb(225,228,232);
    		overflow: auto;
    	}
    	table td {
    		padding: 8px;
    	}
    	.tabIt td {
    		padding: 8px;
    		border-bottom: 1px solid rgb(200,200,200);
    		border-right: 1px solid rgb(200,200,200);
    		font-family: Arial;
    		font-size: 12pt; cursor: pointer;
    		color: #000000; text-align: center;
    		background-color: #ffffff;
    	}
    	.tabIt td:hover, .tabIt td:focus {
    		color: #ffffff;
    		background-color: rgb(80,105,140);
    	}
    </style>
	</head>
	<body>
		<table border = "0" cellspacing = "0" cellpadding = "0" width = "100%" class = "tabIt">
			<tr>
				<td id = "tab0" onclick = "javascript:tabIt(0);"><?php echo $tab0; ?></td>
				<td id = "tab1" onclick = "javascript:tabIt(1);"><?php echo $tab1; ?></td>
				<td id = "tab2" onclick = "javascript:tabIt(2);" style = "border-right:none;"><?php echo $tab2; ?></td>
			</tr>
		</table>
		<div id = "panel0" style = "display:block;">
		
		</div>
		<div id = "panel1" style = "display:none;">
			<table border = "0" cellspacing = "0" cellpadding = "0" width = "100%">
				<tr>
					<td valign = "top" style = "vertical-align:top;">
						<?php echo $navi; ?>
					</td>
					<td valign = "top" style = "vertical-align:top;">
						<?php echo $butt; ?>
					</td>
					<td valign = "top" style = "vertical-align:top;">
						<?php echo $conf; ?>
					</td>
				</tr>
				<tr>
					<td valign = "top" style = "vertical-align:top;">
						<div style = "overflow:auto;height:280px;">
							<?php
								$n = 0;
								foreach( array(
									"img/a01.png", "img/a02.png", "img/a03.png",
									"img/a04.png", "img/a06.png", "img/a10.png",
									"img/a11.png", "img/a12.png", "img/a13.png",
									"img/a14.png", "img/a15.png", "img/a16.png",
									"img/a20.png", "img/a22.png"
								) as $a ) {
									echo '<div style = "background-color:rgb(225,228,232);">
									     <table border = "0" cellspacing = "0" 
							             cellpadding = "0" width = "100%"><tr>
							             <td><input type = "radio" name = "radi" value="'.$a.'">
							             </td><td><img border = "0" src = "'.$a.'" style = "width:200px;"></td>
							             </tr></table></div>';
								}
							?>
						</div>
					</td>
					<td valign = "top" style = "vertical-align:top;">
						<div style = "overflow:auto;height:280px;">
							<?php
								$n = 0;
								foreach( array(
									"img/b03.png", "img/b05.png", "img/b06.png",
									"img/b07.png", "img/b11.png", "img/b14.png",
									"img/b17.png", "img/b20.png", "img/b21.png"
								) as $a ) {
									echo '<div style = "background-color:rgb(225,228,232);">
									     <table border = "0" cellspacing = "0" 
							             cellpadding = "0" width = "100%"><tr>
							             <td><input type = "radio" name = "rado" value="'.$a.'">
							             </td><td><img border = "0" src = "'.$a.'"></td>
							             </tr></table></div>';
								}
							?>
						</div>
					</td>
					<td valign = "top" style = "vertical-align:top;">
						<div style = "overflow:auto;height:280px;width:150px;">
							Breite:<br>
							<input type = "text" value = "100%" id = "breit" name = "breit" style = "width:60px;text-align:right;"><br>
							H&ouml;he:<br>
							<input type = "text" value = "100%" id = "hoehe" name = "hoehe" style = "width:60px;text-align:right;"><br>
							Geschwindigkeit:<br>
							<input type = "number" value = "1500" id = "speed" name = "speed" style = "width:60px;text-align:right;"><br>
							Interval:<br>
							<input type = "number" value = "3000" id = "intvl" name = "intvl" style = "width:60px;text-align:right;"><br>
							AutoPlay:<br>
							<select size = "1" id = "aplay" name = "aplay">
								<option value = "0">Nein</option>
								<option value = "1">Ja</option>
							</select><br>
							Richtung:<br>
							<select size = "1" id = "direc" name = "direc">
								<option value = "1">Horizontal</option>
								<option value = "2">Vertikal</option>
							</select>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<div id = "panel2" style = "display:none;">
		
		</div>
	</body>
</html>

<script>
	tabIt(0);
</script>
