<?php
	switch ( $_SESSION['lang'] ) {
		case 'de':
			$tooltip = ctu("F[uu]gt einen neuen Tab-Panel ein");
			$title = "Tab-Panel";
			$label1 = "Klick-Tabs mit Buttons oben";
			$label2 = "Klick-Tabs mit Buttons unten";
			$label3 = "Roll-Tabs mit Buttons oben";
			$label4 = "Roll-Tabs mit Buttons unten";
			$labelb = "Button";
			$labelc = "Buttons";
			$labeld = "Inhalt";
			break;
		case 'tr':
			$tooltip = ctu("Yeni bir Tab-Paneli ekle");
			$title = "Tab-Panel";
			$label1 = ctu("T[ii]klan[ii]r Tab'lar ve [uu]stte butonlar");
			$label2 = ctu("T[ii]klan[ii]r Tab'lar ve altta butonlar");
			$label3 = ctu("Fare-Takipli Tab'lar ve [uu]stte butonlar");
			$label4 = ctu("Fare-Takipli Tab'lar ve altta butonlar");
			$labelb = "Buton";
			$labelc = "Buton";
			$labeld = ctu("[Ii][cc]erik");
			break;
		default:
			$tooltip = "Add a new tab-panel";
			$title = "Tab-Panel";
			$label1 = "Click-Tabs and buttons on top";
			$label2 = "Click-Tabs and buttons on bottom";
			$label3 = "Hover-Tabs and buttons on top";
			$label4 = "Hover-Tabs and buttons on bottom";
			$labelb = "Button";
			$labelc = "Buttons";
			$labeld = "Content";
			break;
	}
?>
/*
								editor.addButton( '5MPlugin_Embedded_Tabs', {
									text: '<?php echo $title; ?>',
									tooltip: '<?php echo $tooltip; ?>',
									type: 'menubutton',
									icon: false,
									menu: [
										{
											text: '<?php echo $label1; ?>',
											onclick: function(){
											},
											menu: [
												{ text: '1 <?php echo $labelb; ?>', onclick: function() {
													editor.insertContent('<div style = "margin:5px;"><br /><br /><br /></div>');
												}},
											]
										}
									]
								});
*/

								editor.addButton( '5MPlugin_Embedded_Tabs', {
									text: '<?php echo $title; ?>',
									tooltip: '<?php echo $tooltip; ?>',
									type: 'menubutton',
									icon: false,
									onclick: function() {
										/*var properties = '';
										  for (property in this) {
											properties += ', ' + property;
										  }
										  alert('Properties of object:' + properties);*/
										// *** //
										var b = document.getElementById(this._id);
										var left = b.offsetLeft + 10;
										var top  = (parseInt(b.offsetTop) + parseInt(b.offsetHeight) + 31);
										// *** //
										var o = document.getElementById('tmce_embedded_tabs_popup_box');
										// *** //
										o.style.top = top + 'px';
										o.style.left = left + 'px';
										o.style.display = 'block';
										// *** //
										tmce_actice_force_to_hide = "tmce_embedded_tabs_popup_box";
										// *** //
										tmce_active_editor_instance = tinyMCE.activeEditor;
										// *** //
										//alert(tmce_active_editor_instance.id);
/*var all = document.getElementsByTagName("*");
var ar = ""; var properties = "";
for (var i=0, max=all.length; i < max; i++) {
     //ar += all[i].id + "[" + all[i].name + "], ";
	 ar += "ID:" + all[i].id + "[";
	ar += properties + "]<br />";
}
tinyMCE.activeEditor.insertContent(ar);*/
//alert(document.getElementById(tmce_actice_force_to_hide));
									}
								});
