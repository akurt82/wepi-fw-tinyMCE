<?php
	switch ( $_SESSION['lang'] ) {
		case 'de':
			$tooltip = ctu("F[uu]gt ein Feld mit Innenabstand ein");
			$title = "Abstand";
			$label1 = "Von allen Seiten";
			$label2 = "Nach oben";
			$label3 = "Nach unten";
			$label4 = "Nach links";
			$label5 = "Nach rechts";
			$label6 = "Nach links und rechts";
			$label7 = "Nach oben und unten";
			break;
		case 'tr':
			$tooltip = ctu("[Ii][cc]-mesafeli bir alan ekle");
			$title = "Mesafe";
			$label1 = ctu("T[uu]m kenarlara");
			$label2 = "Yukardan";
			$label3 = "Alttan";
			$label4 = "Soldan";
			$label5 = ctu("Sa[gg]dan");
			$label6 = ctu("Soldan ve Sa[gg]dan");
			$label7 = ctu("Yukardan ve A[sh]a[gg][ii]dan");
			break;
		default:
			$tooltip = "Add a field with inner-padding";
			$title = "Padding";
			$label1 = "From all sides";
			$label2 = "From top";
			$label3 = "From bottom";
			$label4 = "From left";
			$label5 = "From right";
			$label6 = "From left and right";
			$label7 = "From top and bottom";
			break;
	}
?>

								editor.addButton( '5MPlugin_Embedded_Paddings', {
									text: '<?php echo $title; ?>',
									tooltip: '<?php echo $tooltip; ?>',
									type: 'menubutton',
									icon: false,
									menu: [
										{
											text: '<?php echo $label1; ?>',
											onclick: function(){
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "padding:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "padding:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "padding:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "padding:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "padding:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "padding:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "padding:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "padding:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "padding:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "padding:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "padding:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "padding:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "padding:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "padding:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "padding:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "padding:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "padding:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "padding:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "padding:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "padding:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label2; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "padding-top:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "padding-top:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "padding-top:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "padding-top:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "padding-top:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "padding-top:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "padding-top:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "padding-top:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "padding-top:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "padding-top:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "padding-top:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "padding-top:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "padding-top:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "padding-top:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "padding-top:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "padding-top:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "padding-top:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "padding-top:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "padding-top:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "padding-top:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label3; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "padding-bottom:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label4; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "padding-left:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "padding-left:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "padding-left:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "padding-left:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "padding-left:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "padding-left:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "padding-left:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "padding-left:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "padding-left:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "padding-left:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "padding-left:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "padding-left:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "padding-left:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "padding-left:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "padding-left:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "padding-left:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "padding-left:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "padding-left:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "padding-left:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "padding-left:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label5; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "padding-right:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "padding-right:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "padding-right:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "padding-right:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "padding-right:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "padding-right:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "padding-right:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "padding-right:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "padding-right:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "padding-right:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "padding-right:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "padding-right:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "padding-right:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "padding-right:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "padding-right:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "padding-right:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "padding-right:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "padding-right:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "padding-right:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "padding-right:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label6; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "padding-left:10px; padding-right:10px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "padding-left:20px; padding-right:20px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "padding-left:30px; padding-right:30px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "padding-left:40px; padding-right:40px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "padding-left:50px; padding-right:50px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "padding-left:75px; padding-right:75px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "padding-left:100px; padding-right:100px;"><br /><br /><br /></div>');
												}},
												{ text: '125px', onclick: function(){
													editor.insertContent('<div style = "padding-left:125px; padding-right:125px;"><br /><br /><br /></div>');
												}},
												{ text: '150px', onclick: function(){
													editor.insertContent('<div style = "padding-left:150px; padding-right:150px;"><br /><br /><br /></div>');
												}},
												{ text: '175px', onclick: function(){
													editor.insertContent('<div style = "padding-left:175px; padding-right:175px;"><br /><br /><br /></div>');
												}},
												{ text: '200px', onclick: function(){
													editor.insertContent('<div style = "padding-left:200px; padding-right:200px;"><br /><br /><br /></div>');
												}},
												{ text: '225px', onclick: function(){
													editor.insertContent('<div style = "padding-left:225px; padding-right:225px;"><br /><br /><br /></div>');
												}},
												{ text: '250px', onclick: function(){
													editor.insertContent('<div style = "padding-left:250px; padding-right:250px;"><br /><br /><br /></div>');
												}},
												{ text: '275px', onclick: function(){
													editor.insertContent('<div style = "padding-left:275px; padding-right:275px;"><br /><br /><br /></div>');
												}},
												{ text: '350px', onclick: function(){
													editor.insertContent('<div style = "padding-left:350px; padding-right:350px;"><br /><br /><br /></div>');
												}},
												{ text: '400px', onclick: function(){
													editor.insertContent('<div style = "padding-left:400px; padding-right:400px;"><br /><br /><br /></div>');
												}},
												{ text: '450px', onclick: function(){
													editor.insertContent('<div style = "padding-left:450px; padding-right:450px;"><br /><br /><br /></div>');
												}},
												{ text: '500px', onclick: function(){
													editor.insertContent('<div style = "padding-left:500px; padding-right:500px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label7; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "padding-top:10px; padding-bottom:10px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "padding-top:20px; padding-bottom:20px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "padding-top:30px; padding-bottom:30px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "padding-top:40px; padding-bottom:40px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "padding-top:50px; padding-bottom:50px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "padding-top:75px; padding-bottom:75px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "padding-top:100px; padding-bottom:100px;"><br /><br /><br /></div>');
												}},
												{ text: '125px', onclick: function(){
													editor.insertContent('<div style = "padding-top:125px; padding-bottom:125px;"><br /><br /><br /></div>');
												}},
												{ text: '150px', onclick: function(){
													editor.insertContent('<div style = "padding-top:150px; padding-bottom:150px;"><br /><br /><br /></div>');
												}},
												{ text: '175px', onclick: function(){
													editor.insertContent('<div style = "padding-top:175px; padding-bottom:175px;"><br /><br /><br /></div>');
												}},
												{ text: '200px', onclick: function(){
													editor.insertContent('<div style = "padding-top:200px; padding-bottom:200px;"><br /><br /><br /></div>');
												}},
												{ text: '225px', onclick: function(){
													editor.insertContent('<div style = "padding-top:225px; padding-bottom:225px;"><br /><br /><br /></div>');
												}},
												{ text: '250px', onclick: function(){
													editor.insertContent('<div style = "padding-top:250px; padding-bottom:250px;"><br /><br /><br /></div>');
												}},
												{ text: '275px', onclick: function(){
													editor.insertContent('<div style = "padding-top:275px; padding-bottom:275px;"><br /><br /><br /></div>');
												}},
												{ text: '350px', onclick: function(){
													editor.insertContent('<div style = "padding-top:350px; padding-bottom:350px;"><br /><br /><br /></div>');
												}},
												{ text: '400px', onclick: function(){
													editor.insertContent('<div style = "padding-top:400px; padding-bottom:400px;"><br /><br /><br /></div>');
												}},
												{ text: '450px', onclick: function(){
													editor.insertContent('<div style = "padding-top:450px; padding-bottom:450px;"><br /><br /><br /></div>');
												}},
												{ text: '500px', onclick: function(){
													editor.insertContent('<div style = "padding-top:500px; padding-bottom:500px;"><br /><br /><br /></div>');
												}},
											]
										}
									]
								});
