<?php

	/*
		ß \00DF			Ä \00C4			ä \00E4
		Ö \00D6			ö \00F6
		Ü \00DC			ü \00FC
		Ç \00C7			ç \00E7
		Ş \015E			ç \015F
		Ğ \011E			ğ \011F
		İ \0130			ı \0131

		TURKISH LIRA \20A4
	*/

	function ctu( $text ) {
		$temp = $text;
		// *** //
		$temp = str_replace( "[sz]", "\u00DF", $temp );
		$temp = str_replace( "[Aa]", "\u00C4", $temp );
		$temp = str_replace( "[aa]", "\u00E4", $temp );
		$temp = str_replace( "[Oo]", "\u00D6", $temp );
		$temp = str_replace( "[oo]", "\u00F6", $temp );
		$temp = str_replace( "[Uu]", "\u00DC", $temp );
		$temp = str_replace( "[uu]", "\u00FC", $temp );
		$temp = str_replace( "[Cc]", "\u00C7", $temp );
		$temp = str_replace( "[cc]", "\u00E7", $temp );
		$temp = str_replace( "[Sh]", "\u015E", $temp );
		$temp = str_replace( "[sh]", "\u015F", $temp );
		$temp = str_replace( "[Gg]", "\u011E", $temp );
		$temp = str_replace( "[gg]", "\u011F", $temp );
		$temp = str_replace( "[Ii]", "\u0130", $temp );
		$temp = str_replace( "[ii]", "\u0131", $temp );
		$temp = str_replace( "[tl]", "\u20A4", $temp );
		//$temp = str_replace( "[eu]", "\00DF", $temp ); für Euro
		// *** //
		return $temp;
	}

?>
