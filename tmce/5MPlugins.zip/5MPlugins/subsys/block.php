<?php
	switch ( $_SESSION['lang'] ) {
		case 'de':
			$tooltip = ctu("F[uu]gt ein Block ein");
			$title = "Block";
			$label1 = "Flach";
			$label2 = "Mit eckigen Rahmen";
			$label3 = "Mit abgerundeten Rahmen";
			$label4 = "Mit oberen, abgerundeten Rahmen";
			$label5 = "Mit unteren, abgerundeten Rahmen";
			break;
		case 'tr':
			$tooltip = ctu("Blok ekle");
			$title = "Blok";
			$label1 = ctu("D[uu]z");
			$label2 = ctu("Sade [Cc]er[cc]eve");
			$label3 = ctu("Yuvarlak kenarl[ii]kl[ii]");
			$label4 = ctu("[Uu]stten yuvarlak kenarl[ii]kl[ii]");
			$label5 = ctu("Alttan yuvarlak kenarl[ii]kl[ii]");
			break;
		default:
			$tooltip = "Add a block";
			$title = "Block";
			$label1 = "Flat";
			$label2 = "With corners";
			$label3 = "With rounded corners";
			$label4 = "With top, rounded corners";
			$label5 = "With bottom, rounded corners";
			break;
	}
?>

								editor.addButton( '5MPlugin_Embedded_Block', {
									text: '<?php echo $title; ?>',
									tooltip: '<?php echo $tooltip; ?>',
									type: 'menubutton',
									icon: false,
									menu: [
										{
											text: '<?php echo $label1; ?>',
											onclick: function(){
											},
											menu: [
												{ text: '<div style = "background-color: #000000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000000; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #202020; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #202020; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #404040; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #404040; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #606060; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #606060; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #808080; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #808080; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #F0F0F0; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #F0F0F0; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000033; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000066; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000066; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000099; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000099; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0000FF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0000FF; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003300; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003333; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003366; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003399; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003399; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0033CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0033CC; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #006633; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #006633; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #009999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #009999; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0099CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0099CC; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF00; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF99; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #330000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #330000; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333300; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333333; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660000; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660033; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663300; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663333; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663366; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #666699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #666699; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #6699CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #6699CC; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCCC; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCFF; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #990000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #990000; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #993333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #993333; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #996699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #996699; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #999999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #999999; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #9999CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #9999CC; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC0000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC0000; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC3300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC3300; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC6600; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC6600; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC9966; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCCC99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCCC99; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCFF00; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCFF00; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9966; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9999; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCCC; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCFF; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9900; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCC00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCC00; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF00; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF66; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF66; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF99; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFCC; width: 100%;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFFF; width: 100%;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label2; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '<div style = "background-color: #000000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #121212; width: 100%; border: 1px solid #000000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #202020; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #202020; width: 100%; border: 1px solid #000000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #404040; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #404040; width: 100%; border: 1px solid #202020;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #606060; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #606060; width: 100%; border: 1px solid #303030;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #808080; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #808080; width: 100%; border: 1px solid #404040;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #F0F0F0; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #F0F0F0; width: 100%; border: 1px solid #C0C0C0;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000033; width: 100%; border: 1px solid #000005;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000066; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000066; width: 100%; border: 1px solid #000022;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000099; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000099; width: 100%; border: 1px solid #000044;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0000FF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0000FF; width: 100%; border: 1px solid #0000CC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003300; width: 100%; border: 1px solid #000500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003333; width: 100%; border: 1px solid #001010;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003366; width: 100%; border: 1px solid #001133;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003399; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003399; width: 100%; border: 1px solid #001144;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0033CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0033CC; width: 100%; border: 1px solid #0011AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #006633; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #006633; width: 100%; border: 1px solid #003311;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #009999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #009999; width: 100%; border: 1px solid #001111;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0099CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0099CC; width: 100%; border: 1px solid #0033AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF00; width: 100%; border: 1px solid #00BB00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF99; width: 100%; border: 1px solid #00BB33;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #330000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #330000; width: 100%; border: 1px solid #050000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333300; width: 100%; border: 1px solid #050500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333333; width: 100%; border: 1px solid #050505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660000; width: 100%; border: 1px solid #330000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660033; width: 100%; border: 1px solid #330005;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663300; width: 100%; border: 1px solid #330500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663333; width: 100%; border: 1px solid #330505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663366; width: 100%; border: 1px solid #330533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #666699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #666699; width: 100%; border: 1px solid #333355;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #6699CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #6699CC; width: 100%; border: 1px solid #3355AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCCC; width: 100%; border: 1px solid #33AAAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCFF; width: 100%; border: 1px solid #33AACC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #990000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #990000; width: 100%; border: 1px solid #550000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #993333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #993333; width: 100%; border: 1px solid #550505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #996699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #996699; width: 100%; border: 1px solid #553355;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #999999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #999999; width: 100%; border: 1px solid #555555;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #9999CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #9999CC; width: 100%; border: 1px solid #5555AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC0000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC0000; width: 100%; border: 1px solid #AA0000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC3300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC3300; width: 100%; border: 1px solid #AA0500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC6600; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC6600; width: 100%; border: 1px solid #AA3300;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC9966; width: 100%; border: 1px solid #AA5533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCCC99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCCC99; width: 100%; border: 1px solid #AAAA55;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCFF00; width: 100%; border: 1px solid #AACC00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9900; width: 100%; border: 1px solid #CC5500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9966; width: 100%; border: 1px solid #CC5533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9999; width: 100%; border: 1px solid #CC5555;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCCC; width: 100%; border: 1px solid #CCAAAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCFF; width: 100%; border: 1px solid #CCAACC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9900; width: 100%; border: 1px solid #CC5500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCC00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCC00; width: 100%; border: 1px solid #CCAA00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF00; width: 100%; border: 1px solid #CCCC00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF66; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF66; width: 100%; border: 1px solid #CCCC33;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF99; width: 100%; border: 1px solid #CCCC55;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFCC; width: 100%; border: 1px solid #CCCCAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFFF; width: 100%; border: 1px solid #CCCCCC;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label3; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '<div style = "background-color: #000000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #121212; width: 100%; border-radius: 8px; border: 1px solid #000000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #202020; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #202020; width: 100%; border-radius: 8px; border: 1px solid #000000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #404040; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #404040; width: 100%; border-radius: 8px; border: 1px solid #202020;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #606060; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #606060; width: 100%; border-radius: 8px; border: 1px solid #303030;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #808080; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #808080; width: 100%; border-radius: 8px; border: 1px solid #404040;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #F0F0F0; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #F0F0F0; width: 100%; border-radius: 8px; border: 1px solid #C0C0C0;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000033; width: 100%; border-radius: 8px; border: 1px solid #000005;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000066; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000066; width: 100%; border-radius: 8px; border: 1px solid #000022;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000099; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000099; width: 100%; border-radius: 8px; border: 1px solid #000044;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0000FF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0000FF; width: 100%; border-radius: 8px; border: 1px solid #0000CC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003300; width: 100%; border-radius: 8px; border: 1px solid #000500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003333; width: 100%; border-radius: 8px; border: 1px solid #001010;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003366; width: 100%; border-radius: 8px; border: 1px solid #001133;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003399; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003399; width: 100%; border-radius: 8px; border: 1px solid #001144;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0033CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0033CC; width: 100%; border-radius: 8px; border: 1px solid #0011AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #006633; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #006633; width: 100%; border-radius: 8px; border: 1px solid #003311;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #009999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #009999; width: 100%; border-radius: 8px; border: 1px solid #001111;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0099CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0099CC; width: 100%; border-radius: 8px; border: 1px solid #0033AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF00; width: 100%; border-radius: 8px; border: 1px solid #00BB00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF99; width: 100%; border-radius: 8px; border: 1px solid #00BB33;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #330000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #330000; width: 100%; border-radius: 8px; border: 1px solid #050000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333300; width: 100%; border-radius: 8px; border: 1px solid #050500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333333; width: 100%; border-radius: 8px; border: 1px solid #050505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660000; width: 100%; border-radius: 8px; border: 1px solid #330000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660033; width: 100%; border-radius: 8px; border: 1px solid #330005;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663300; width: 100%; border-radius: 8px; border: 1px solid #330500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663333; width: 100%; border-radius: 8px; border: 1px solid #330505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663366; width: 100%; border-radius: 8px; border: 1px solid #330533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #666699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #666699; width: 100%; border-radius: 8px; border: 1px solid #333355;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #6699CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #6699CC; width: 100%; border-radius: 8px; border: 1px solid #3355AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCCC; width: 100%; border-radius: 8px; border: 1px solid #33AAAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCFF; width: 100%; border-radius: 8px; border: 1px solid #33AACC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #990000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #990000; width: 100%; border-radius: 8px; border: 1px solid #550000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #993333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #993333; width: 100%; border-radius: 8px; border: 1px solid #550505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #996699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #996699; width: 100%; border-radius: 8px; border: 1px solid #553355;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #999999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #999999; width: 100%; border-radius: 8px; border: 1px solid #555555;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #9999CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #9999CC; width: 100%; border-radius: 8px; border: 1px solid #5555AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC0000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC0000; width: 100%; border-radius: 8px; border: 1px solid #AA0000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC3300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC3300; width: 100%; border-radius: 8px; border: 1px solid #AA0500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC6600; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC6600; width: 100%; border-radius: 8px; border: 1px solid #AA3300;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC9966; width: 100%; border-radius: 8px; border: 1px solid #AA5533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCCC99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCCC99; width: 100%; border-radius: 8px; border: 1px solid #AAAA55;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCFF00; width: 100%; border-radius: 8px; border: 1px solid #AACC00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9900; width: 100%; border-radius: 8px; border: 1px solid #CC5500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9966; width: 100%; border-radius: 8px; border: 1px solid #CC5533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9999; width: 100%; border-radius: 8px; border: 1px solid #CC5555;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCCC; width: 100%; border-radius: 8px; border: 1px solid #CCAAAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCFF; width: 100%; border-radius: 8px; border: 1px solid #CCAACC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9900; width: 100%; border-radius: 8px; border: 1px solid #CC5500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCC00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCC00; width: 100%; border-radius: 8px; border: 1px solid #CCAA00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF00; width: 100%; border-radius: 8px; border: 1px solid #CCCC00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF66; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF66; width: 100%; border-radius: 8px; border: 1px solid #CCCC33;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF99; width: 100%; border-radius: 8px; border: 1px solid #CCCC55;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFCC; width: 100%; border-radius: 8px; border: 1px solid #CCCCAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFFF; width: 100%; border-radius: 8px; border: 1px solid #CCCCCC;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label4; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '<div style = "background-color: #000000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #121212; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #000000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #202020; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #202020; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #000000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #404040; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #404040; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #202020;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #606060; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #606060; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #303030;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #808080; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #808080; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #404040;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #F0F0F0; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #F0F0F0; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #C0C0C0;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000033; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #000005;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000066; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000066; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #000022;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000099; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000099; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #000044;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0000FF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0000FF; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #0000CC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003300; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #000500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003333; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #001010;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003366; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #001133;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003399; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003399; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #001144;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0033CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0033CC; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #0011AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #006633; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #006633; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #003311;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #009999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #009999; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #001111;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0099CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0099CC; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #0033AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF00; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #00BB00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF99; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #00BB33;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #330000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #330000; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #050000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333300; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #050500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333333; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #050505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660000; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #330000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660033; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #330005;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663300; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #330500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663333; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #330505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663366; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #330533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #666699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #666699; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #333355;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #6699CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #6699CC; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #3355AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCCC; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #33AAAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCFF; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #33AACC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #990000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #990000; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #550000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #993333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #993333; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #550505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #996699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #996699; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #553355;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #999999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #999999; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #555555;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #9999CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #9999CC; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #5555AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC0000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC0000; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #AA0000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC3300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC3300; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #AA0500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC6600; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC6600; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #AA3300;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC9966; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #AA5533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCCC99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCCC99; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #AAAA55;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCFF00; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #AACC00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9900; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CC5500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9966; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CC5533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9999; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CC5555;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCCC; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CCAAAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCFF; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CCAACC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9900; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CC5500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCC00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCC00; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CCAA00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF00; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CCCC00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF66; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF66; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CCCC33;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF99; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CCCC55;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFCC; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CCCCAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFFF; width: 100%; border-top-left-radius: 8px; border-top-right-radius: 8px; border: 1px solid #CCCCCC;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label5; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '<div style = "background-color: #000000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #121212; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #000000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #202020; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #202020; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #000000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #404040; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #404040; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #202020;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #606060; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #606060; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #303030;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #808080; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #808080; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #404040;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #F0F0F0; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #F0F0F0; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #C0C0C0;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000033; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #000005;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000066; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000066; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #000022;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #000099; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #000099; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #000044;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0000FF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0000FF; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #0000CC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003300; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #000500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003333; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #001010;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003366; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #001133;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #003399; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #003399; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #001144;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0033CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0033CC; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #0011AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #006633; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #006633; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #003311;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #009999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #009999; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #001111;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #0099CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #0099CC; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #0033AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF00; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #00BB00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #00FF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #00FF99; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #00BB33;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #330000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #330000; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #050000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333300; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #050500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #333333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #333333; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #050505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660000; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #330000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #660033; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #660033; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #330005;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663300; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #330500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663333; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #330505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #663366; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #663366; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #330533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #666699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #666699; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #333355;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #6699CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #6699CC; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #3355AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCCC; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #33AAAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #66CCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #66CCFF; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #33AACC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #990000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #990000; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #550000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #993333; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #993333; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #550505;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #996699; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #996699; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #553355;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #999999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #999999; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #555555;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #9999CC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #9999CC; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #5555AA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC0000; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC0000; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #AA0000;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC3300; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC3300; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #AA0500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC6600; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC6600; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #AA3300;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CC9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CC9966; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #AA5533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCCC99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCCC99; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #AAAA55;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #CCFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #CCFF00; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #AACC00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9900; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CC5500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9966; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9966; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CC5533;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9999; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9999; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CC5555;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCCC; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CCAAAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCCFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCCFF; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CCAACC;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FF9900; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FF9900; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CC5500;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFCC00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFCC00; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CCAA00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF00; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF00; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CCCC00;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF66; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF66; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CCCC33;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFF99; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFF99; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CCCC55;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFCC; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFCC; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CCCCAA;"><br /><br /><br /></div>');
												}},
												{ text: '<div style = "background-color: #FFFFFF; width: 160px; height: 20px;">&nbsp;</div>', type: 'SplitButton', onclick: function(){
														editor.insertContent('<div style = "background-color: #FFFFFF; width: 100%; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border: 1px solid #CCCCCC;"><br /><br /><br /></div>');
												}},
											]
										}
									]
								});
