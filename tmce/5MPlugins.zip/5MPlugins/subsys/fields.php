<?php
	switch ( $_SESSION['lang'] ) {
		case 'de':
			$tooltip = ctu("F[uu]gt ein eingeschrenktes Feld mit Rollfunktion ein");
			$title = "Feld";
			$label1 = "Rollbar auf der X- und Y-Achse";
			$label2 = "Rollbar nur auf der X-Achse";
			$label3 = "Rollbar nur auf der Y-Achse";
			break;
		case 'tr':
			$tooltip = ctu("Dikey boyutu s[ii]n[ii]rl[ii] ve i[cc]eri[gg]i kayd[ii]r[ii]labilir bir alan ekle");
			$title = "Alan";
			$label1 = ctu("Yatay ve dikey boyutta kayd[ii]r[ii]l[ii]r");
			$label2 = ctu("sadece yatay boyutta kayd[ii]r[ii]l[ii]r");
			$label3 = ctu("Sadece dikey boyutta kayd[ii]r[ii]l[ii]r");
			break;
		default:
			$tooltip = "Add a field with pre-defined height that can be scrolled";
			$title = "Field";
			$label1 = "Full scrollable";
			$label2 = "Scrollable horizontally only";
			$label3 = "Scrollable vertically only";
			break;
	}
?>

								editor.addButton( '5MPlugin_Embedded_Fields', {
									text: '<?php echo $title; ?>',
									tooltip: '<?php echo $tooltip; ?>',
									type: 'menubutton',
									icon: false,
									menu: [
										{
											text: '<?php echo $label1; ?>',
											onclick: function(){
											},
											menu: [
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 100px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '150px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 150px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '200px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 200px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '250px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 250px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '300px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 300px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '350px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 350px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '400px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 400px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '450px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 450px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '500px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 500px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '550px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 550px; overflow: auto;"><br /><br /><br /></div>');
												}},
												{ text: '600px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 600px; overflow: auto;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label2; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 100px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '150px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 150px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '200px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 200px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '250px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 250px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '300px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 300px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '350px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 350px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '400px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 400px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '450px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 450px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '500px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 500px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '550px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 550px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
												{ text: '600px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 600px; overflow-y: hidden; overflow-x: auto;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label3; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 100px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '150px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 150px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '200px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 200px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '250px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 250px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '300px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 300px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '350px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 350px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '400px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 400px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '450px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 450px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '500px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 500px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '550px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 550px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
												{ text: '600px', onclick: function(){
													editor.insertContent('<div style = "min-width: 5px; height: 600px; overflow-x: hidden; overflow-y: auto;"><br /><br /><br /></div>');
												}},
											]
										}
									]
								});
