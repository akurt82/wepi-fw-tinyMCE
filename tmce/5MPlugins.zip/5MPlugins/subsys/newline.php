<?php
	switch ( $_SESSION['lang'] ) {
		case 'de':
			$tooltip = ctu("Neue Zeile am Ende des Inhalts einf[uu]gen");
			$title = "Neue Zeile";
			break;
		case 'tr':
			$tooltip = ctu("[Ii][cc]eri[gg]in sonuna yeni sat[ii]r ekle");
			$title = ctu("Yeni sat[ii]r");
			break;
		default:
			$tooltip = "Add a new line to the end of the content";
			$title = "New line";
			break;
	}
?>

								editor.addButton( '5MPlugin_Embedded_NewLine', {
									text: '<?php echo $title; ?>',
									tooltip: '<?php echo $tooltip; ?>',
									type: 'button',
									icon: false,
									onclick: function() {
										tinyMCE.activeEditor.dom.add(tinyMCE.activeEditor.getBody(), 'br', {title : ''}, '');
									}
								});
