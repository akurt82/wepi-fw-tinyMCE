<?php
	switch ( $_SESSION['lang'] ) {
		case 'de':
			$tooltip = ctu("Neuen Abschnitt mit Trennlinie einf[uu]gen");
			$title = "Trenner";
			$label1 = "Von oben";
			$label2 = "Von links";
			$label3 = "Von rechts";
			$label4 = "Streifen";
			$label5 = "Gebrochener Streifen";
			$label6 = "Punktiert";
			break;
		case 'tr':
			$tooltip = ctu("Ay[ii]r[ii]c[ii] [cc]izgisiyle yeni k[ii]s[ii]m ekle");
			$title = ctu("Ay[ii]r[ii]c[ii]");
			$label1 = "Yukardan";
			$label2 = "Soldan";
			$label3 = ctu("Sa[gg]dan");
			$label4 = ctu("Tam [cc]izgi");
			$label5 = ctu("Kesik [cc]izgi");
			$label6 = ctu("Noktal[ii]");
			break;
		default:
			$tooltip = "Add a new block by a separator-line";
			$title = "Separator";
			$label1 = "From top";
			$label2 = "From left";
			$label3 = "From right";
			$label4 = "Line";
			$label5 = "Broken line";
			$label6 = "Dotted";
			break;
	}
?>

								editor.addButton( '5MPlugin_Embedded_Separators', {
									text: '<?php echo $title; ?>',
									tooltip: '<?php echo $tooltip; ?>',
									type: 'menubutton',
									icon: false,
									menu: [
										{
											text: '<?php echo $label1; ?>',
											onclick: function(){
											},
											menu: [
												{ text: '<?php echo $label4; ?>', onclick: function(){
													editor.insertContent('<div style = "border-top: 1px solid #000000; padding-top: 10px; margin-top: 10px;"><br /><br /><br /></div>');
												}},
												{ text: '<?php echo $label5; ?>', onclick: function(){
													editor.insertContent('<div style = "border-top: 1px dashed #000000; padding-top: 10px; margin-top: 10px;"><br /><br /><br /></div>');
												}},
												{ text: '<?php echo $label6; ?>', onclick: function(){
													editor.insertContent('<div style = "border-top: 1px dotted #000000; padding-top: 10px; margin-top: 10px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label2; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '<?php echo $label4; ?>', onclick: function(){
													editor.insertContent('<div style = "border-left: 1px solid #000000; padding-left: 10px; margin-left: 10px;"><br /><br /><br /></div>');
												}},
												{ text: '<?php echo $label5; ?>', onclick: function(){
													editor.insertContent('<div style = "border-left: 1px dashed #000000; padding-left: 10px; margin-left: 10px;"><br /><br /><br /></div>');
												}},
												{ text: '<?php echo $label6; ?>', onclick: function(){
													editor.insertContent('<div style = "border-left: 1px dotted #000000; padding-left: 10px; margin-left: 10px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label3; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '<?php echo $label4; ?>', onclick: function(){
													editor.insertContent('<div style = "border-right: 1px solid #000000; padding-right: 10px; margin-right: 10px;"><br /><br /><br /></div>');
												}},
												{ text: '<?php echo $label5; ?>', onclick: function(){
													editor.insertContent('<div style = "border-right: 1px dashed #000000; padding-right: 10px; margin-right: 10px;"><br /><br /><br /></div>');
												}},
												{ text: '<?php echo $label6; ?>', onclick: function(){
													editor.insertContent('<div style = "border-right: 1px dotted #000000; padding-right: 10px; margin-right: 10px;"><br /><br /><br /></div>');
												}},
											]
										}
									]
								});
