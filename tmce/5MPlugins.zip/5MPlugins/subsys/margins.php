<?php
	switch ( $_SESSION['lang'] ) {
		case 'de':
			$tooltip = ctu("F[uu]gt ein Feld mit Au[sz]enabstand ein");
			$title = ctu("Au[sz]enabstand");
			$label1 = "Von allen Seiten";
			$label2 = "Nach oben";
			$label3 = "Nach unten";
			$label4 = "Nach links";
			$label5 = "nach rechts";
			$label6 = "Nach links und rechts";
			$label7 = "Nach oben und unten";
			break;
		case 'tr':
			$tooltip = ctu("D[ii][sh]-mesafeli bir alan ekle");
			$title = ctu("D[ii][sh]-Mesafe");
			$label1 = ctu("T[uu]m kenarlara");
			$label2 = "Yukardan";
			$label3 = "Alttan";
			$label4 = "Soldan";
			$label5 = ctu("Sa[gg]dan");
			$label6 = ctu("Soldan ve Sa[gg]dan");
			$label7 = ctu("Yukardan ve A[sh]a[gg][ii]dan");
			break;
		default:
			$tooltip = "Add a field with outer-margin";
			$title = "Margin";
			$label1 = "From all sides";
			$label2 = "From top";
			$label3 = "From bottom";
			$label4 = "From left";
			$label5 = "From right";
			$label6 = "From left and right";
			$label7 = "From top and bottom";
			break;
	}
?>

								editor.addButton( '5MPlugin_Embedded_Margins', {
									text: '<?php echo $title; ?>',
									tooltip: '<?php echo $tooltip; ?>',
									type: 'menubutton',
									icon: false,
									menu: [
										{
											text: '<?php echo $label1; ?>',
											onclick: function(){
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "margin:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "margin:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "margin:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "margin:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "margin:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "margin:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "margin:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "margin:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "margin:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "margin:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "margin:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "margin:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "margin:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "margin:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "margin:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "margin:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "margin:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "margin:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "margin:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "margin:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label2; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "margin-top:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "margin-top:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "margin-top:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "margin-top:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "margin-top:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "margin-top:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "margin-top:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "margin-top:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "margin-top:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "margin-top:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "margin-top:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "margin-top:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "margin-top:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "margin-top:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "margin-top:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "margin-top:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "margin-top:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "margin-top:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "margin-top:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "margin-top:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label3; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "margin-bottom:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label4; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "margin-left:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "margin-left:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "margin-left:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "margin-left:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "margin-left:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "margin-left:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "margin-left:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "margin-left:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "margin-left:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "margin-left:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "margin-left:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "margin-left:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "margin-left:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "margin-left:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "margin-left:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "margin-left:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "margin-left:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "margin-left:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "margin-left:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "margin-left:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label5; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '5px', onclick: function(){
													editor.insertContent('<div style = "margin-right:5px;"><br /><br /><br /></div>');
												}},
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "margin-right:10px;"><br /><br /><br /></div>');
												}},
												{ text: '15px', onclick: function(){
													editor.insertContent('<div style = "margin-right:15px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "margin-right:20px;"><br /><br /><br /></div>');
												}},
												{ text: '25px', onclick: function(){
													editor.insertContent('<div style = "margin-right:25px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "margin-right:30px;"><br /><br /><br /></div>');
												}},
												{ text: '35px', onclick: function(){
													editor.insertContent('<div style = "margin-right:35px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "margin-right:40px;"><br /><br /><br /></div>');
												}},
												{ text: '45px', onclick: function(){
													editor.insertContent('<div style = "margin-right:45px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "margin-right:50px;"><br /><br /><br /></div>');
												}},
												{ text: '55px', onclick: function(){
													editor.insertContent('<div style = "margin-right:55px;"><br /><br /><br /></div>');
												}},
												{ text: '60px', onclick: function(){
													editor.insertContent('<div style = "margin-right:60px;"><br /><br /><br /></div>');
												}},
												{ text: '65px', onclick: function(){
													editor.insertContent('<div style = "margin-right:65px;"><br /><br /><br /></div>');
												}},
												{ text: '70px', onclick: function(){
													editor.insertContent('<div style = "margin-right:70px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "margin-right:75px;"><br /><br /><br /></div>');
												}},
												{ text: '80px', onclick: function(){
													editor.insertContent('<div style = "margin-right:80px;"><br /><br /><br /></div>');
												}},
												{ text: '85px', onclick: function(){
													editor.insertContent('<div style = "margin-right:85px;"><br /><br /><br /></div>');
												}},
												{ text: '90px', onclick: function(){
													editor.insertContent('<div style = "margin-right:90px;"><br /><br /><br /></div>');
												}},
												{ text: '95px', onclick: function(){
													editor.insertContent('<div style = "margin-right:95px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "margin-right:100px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label6; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "margin-left:10px; margin-right:10px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "margin-left:20px; margin-right:20px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "margin-left:30px; margin-right:30px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "margin-left:40px; margin-right:40px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "margin-left:50px; margin-right:50px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "margin-left:75px; margin-right:75px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "margin-left:100px; margin-right:100px;"><br /><br /><br /></div>');
												}},
												{ text: '125px', onclick: function(){
													editor.insertContent('<div style = "margin-left:125px; margin-right:125px;"><br /><br /><br /></div>');
												}},
												{ text: '150px', onclick: function(){
													editor.insertContent('<div style = "margin-left:150px; margin-right:150px;"><br /><br /><br /></div>');
												}},
												{ text: '175px', onclick: function(){
													editor.insertContent('<div style = "margin-left:175px; margin-right:175px;"><br /><br /><br /></div>');
												}},
												{ text: '200px', onclick: function(){
													editor.insertContent('<div style = "margin-left:200px; margin-right:200px;"><br /><br /><br /></div>');
												}},
												{ text: '225px', onclick: function(){
													editor.insertContent('<div style = "margin-left:225px; margin-right:225px;"><br /><br /><br /></div>');
												}},
												{ text: '250px', onclick: function(){
													editor.insertContent('<div style = "margin-left:250px; margin-right:250px;"><br /><br /><br /></div>');
												}},
												{ text: '275px', onclick: function(){
													editor.insertContent('<div style = "margin-left:275px; margin-right:275px;"><br /><br /><br /></div>');
												}},
												{ text: '350px', onclick: function(){
													editor.insertContent('<div style = "margin-left:350px; margin-right:350px;"><br /><br /><br /></div>');
												}},
												{ text: '400px', onclick: function(){
													editor.insertContent('<div style = "margin-left:400px; margin-right:400px;"><br /><br /><br /></div>');
												}},
												{ text: '450px', onclick: function(){
													editor.insertContent('<div style = "margin-left:450px; margin-right:450px;"><br /><br /><br /></div>');
												}},
												{ text: '500px', onclick: function(){
													editor.insertContent('<div style = "margin-left:500px; margin-right:500px;"><br /><br /><br /></div>');
												}},
											]
										},
										{
											text: '<?php echo $label7; ?>',
											onclick: function() {
											},
											menu: [
												{ text: '10px', onclick: function(){
													editor.insertContent('<div style = "margin-top:10px; margin-bottom:10px;"><br /><br /><br /></div>');
												}},
												{ text: '20px', onclick: function(){
													editor.insertContent('<div style = "margin-top:20px; margin-bottom:20px;"><br /><br /><br /></div>');
												}},
												{ text: '30px', onclick: function(){
													editor.insertContent('<div style = "margin-top:30px; margin-bottom:30px;"><br /><br /><br /></div>');
												}},
												{ text: '40px', onclick: function(){
													editor.insertContent('<div style = "margin-top:40px; margin-bottom:40px;"><br /><br /><br /></div>');
												}},
												{ text: '50px', onclick: function(){
													editor.insertContent('<div style = "margin-top:50px; margin-bottom:50px;"><br /><br /><br /></div>');
												}},
												{ text: '75px', onclick: function(){
													editor.insertContent('<div style = "margin-top:75px; margin-bottom:75px;"><br /><br /><br /></div>');
												}},
												{ text: '100px', onclick: function(){
													editor.insertContent('<div style = "margin-top:100px; margin-bottom:100px;"><br /><br /><br /></div>');
												}},
												{ text: '125px', onclick: function(){
													editor.insertContent('<div style = "margin-top:125px; margin-bottom:125px;"><br /><br /><br /></div>');
												}},
												{ text: '150px', onclick: function(){
													editor.insertContent('<div style = "margin-top:150px; margin-bottom:150px;"><br /><br /><br /></div>');
												}},
												{ text: '175px', onclick: function(){
													editor.insertContent('<div style = "margin-top:175px; margin-bottom:175px;"><br /><br /><br /></div>');
												}},
												{ text: '200px', onclick: function(){
													editor.insertContent('<div style = "margin-top:200px; margin-bottom:200px;"><br /><br /><br /></div>');
												}},
												{ text: '225px', onclick: function(){
													editor.insertContent('<div style = "margin-top:225px; margin-bottom:225px;"><br /><br /><br /></div>');
												}},
												{ text: '250px', onclick: function(){
													editor.insertContent('<div style = "margin-top:250px; margin-bottom:250px;"><br /><br /><br /></div>');
												}},
												{ text: '275px', onclick: function(){
													editor.insertContent('<div style = "margin-top:275px; margin-bottom:275px;"><br /><br /><br /></div>');
												}},
												{ text: '350px', onclick: function(){
													editor.insertContent('<div style = "margin-top:350px; margin-bottom:350px;"><br /><br /><br /></div>');
												}},
												{ text: '400px', onclick: function(){
													editor.insertContent('<div style = "margin-top:400px; margin-bottom:400px;"><br /><br /><br /></div>');
												}},
												{ text: '450px', onclick: function(){
													editor.insertContent('<div style = "margin-top:450px; margin-bottom:450px;"><br /><br /><br /></div>');
												}},
												{ text: '500px', onclick: function(){
													editor.insertContent('<div style = "margin-top:500px; margin-bottom:500px;"><br /><br /><br /></div>');
												}},
											]
										}
									]
								});
